## MWG for Ricardo's RNG problem

# loading required packages
require(Rcpp)

# setting working directory
setwd('C:/Users/uriel/Downloads/rng')

# sourcing external functions
sourceCpp('_src/rng.cpp')

# setting RNG seed
set.seed(42)
N = 2e5

# sampling uniforms
x.R = runif(N)
x.Rcpp = runifRcpp(N);

# plotting densities
par(mfrow = c(1, 2))
hist(x.R)
hist(x.Rcpp)

