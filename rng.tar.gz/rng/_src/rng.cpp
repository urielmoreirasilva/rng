
/* 
    MWE for Ricardo's RNG problem
*/

    
#include <Rcpp.h>
    
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector runifRcpp(const int N){
    // N = number of samples (integer)
    
    // sample with runif (Rcpp syntactic sugar)
    NumericVector x(N);
    for(int i = 0; i < N; ++i){
        x[i] = R::runif(0, 1);
    }
    
    // return
    return x;
}

